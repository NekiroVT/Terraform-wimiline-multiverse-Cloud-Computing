// Public runtime configuration. Set apiUrl to the HTTPS API origin when the
// frontend and API use different hostnames. Never put credentials or secrets here.
window.__MULTIVERSO_CONFIG__ = {
  apiUrl: '/api'
};
